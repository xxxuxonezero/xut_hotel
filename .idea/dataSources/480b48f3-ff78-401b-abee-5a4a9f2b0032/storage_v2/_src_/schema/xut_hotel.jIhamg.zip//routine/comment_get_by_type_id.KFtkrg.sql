create procedure comment_get_by_type_id(IN  in_type_id      int, IN in_offset int, IN in_page_size int,
                                        OUT out_total_count int)
  BEGIN
    SELECT SQL_CALC_FOUND_ROWS * FROM xut_comment WHERE xut_type_id = in_type_id
    LIMIT in_offset, in_page_size;
    SET out_total_count = FOUND_ROWS();
END;

